# Azure-DE-Project-Resources
